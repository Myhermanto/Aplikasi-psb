<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Formulir extends CI_Controller
{

  function __construct(){
    parent::__construct();
      if(!isset($_SESSION['user_email'])){
      redirect('administrator');
      }
      $this->load->model('M_formulir');
      $this->load->model('M_transfer');
      $this->load->library('upload');

  }

  public function data_formulir()
  {
    $data['tampil'] = $this->M_formulir->tampil_data();
    $data['title'] = 'Formulir';
    $data['user'] = $this->db->get_where('tbl_admin', ['user_email' =>
    $this->session->userdata('user_email')])->row_array();
    

    $this->load->view('templates/v_header', $data);
    $this->load->view('admin/v_dashboard_topbar', $data);
    $this->load->view('admin/formulir', $data);
    $this->load->view('templates/v_footer', $data);
  }


  public function detail($id)
  {
      $tampil = $this->M_formulir->detail_data($id);
      $data['tampil'] = $tampil;
      $data['title'] = 'Formulir';
      $data['user'] = $this->db->get_where('tbl_admin', ['user_email' =>
      $this->session->userdata('user_email')])->row_array();

      $this->load->view('templates/v_header', $data);
      $this->load->view('admin/v_dashboard_topbar', $data);
      $this->load->view('admin/formulir_tampil', $data);
      $this->load->view('templates/v_footer', $data);
  }


  public function terima()
  {
    $data['tampil'] = $this->M_formulir->tampil_data();
    $data['title'] = 'Formulir';
    $data['user'] = $this->db->get_where('tbl_admin', ['user_email' =>
    $this->session->userdata('user_email')])->row_array();

    $this->load->view('templates/v_header', $data);
    $this->load->view('admin/v_dashboard_topbar', $data);
    $this->load->view('admin/formulir_terima', $data);
    $this->load->view('templates/v_footer', $data);
  }


  public function tolak()
  {
    $data['tampil'] = $this->M_formulir->tampil_data();
    $data['title'] = 'Formulir';
    $data['user'] = $this->db->get_where('tbl_admin', ['user_email' =>
    $this->session->userdata('user_email')])->row_array();

    $this->load->view('templates/v_header', $data);
    $this->load->view('admin/v_dashboard_topbar', $data);
    $this->load->view('admin/formulir_tolak', $data);
    $this->load->view('templates/v_footer', $data);
  }

  
  public function accept()
  {
    $id      = $this->input->post('kode_siswa');
    $action  = $this->input->post('action');

    $data = array(
      'action' => $action,
    );

    $where = array (
      'kode_siswa' => $id
    );

    $this->M_transfer->update_data($data,'tbl_siswa',$where);

    redirect('admin/formulir/data_formulir');
  }

  public function reject()
  {
    $id      = $this->input->post('kode_siswa');
    $action  = $this->input->post('action');

    $data = array(
      'action' => $action,
    );

    $where = array (
      'kode_siswa' => $id
    );

    $this->M_transfer->update_data($data,'tbl_siswa',$where);

    redirect('admin/formulir/data_formulir');
  }


  public function edit_form($id) {
    $data['title'] = 'Formulir';
    $where = array('kode_siswa' => $id);
    $data['siswa'] = $this->M_formulir->edit_data($where, 'tbl_siswa')->result();
    $data['user'] = $this->db->get_where('tbl_admin', ['user_email' =>
    $this->session->userdata('user_email')])->row_array();


  $this->load->view('templates/v_header', $data);
  $this->load->view('admin/v_dashboard_topbar', $data);
  $this->load->view('admin/formulir_edit', $data);
  $this->load->view('templates/v_footer', $data);
}


public function update_form() {
  $kode_siswa = $this->input->post('kode_siswa');
  $nama_lengkap = $this->input->post('nama_lengkap');
  $nama_panggilan = $this->input->post('nama_panggilan');
  $nisn = $this->input->post('nisn');
  $no_ijazah = $this->input->post('no_ijazah');
  $jenis_kelamin = $this->input->post('jenis_kelamin');
  $tempat_lahir = $this->input->post('tempat_lahir');
  $tanggal_lahir = $this->input->post('tanggal_lahir');
  $agama = $this->input->post('agama');
  $alamat= $this->input->post('alamat');
  $email = $this->input->post('email');
  $no_telp = $this->input->post('no_telp');
  $nama_ayah = $this->input->post('nama_ayah');
  $pekerjaan_ayah = $this->input->post('pekerjaan_ayah');
  $pendidikan_ayah = $this->input->post('pendidikan_ayah');
  $penghasilan_ayah = $this->input->post('penghasilan_ayah');
  $nama_ibu = $this->input->post('nama_ibu');
  $pekerjaan_ibu = $this->input->post('pekerjaan_ibu');
  $pendidikan_ibu = $this->input->post('pendidikan_ibu');
  $penghasilan_ibu = $this->input->post('penghasilan_ibu');
  $nama_wali = $this->input->post('nama_wali');
  $pekerjaan_wali = $this->input->post('pekerjaan_wali');
  $pendidikan_wali = $this->input->post('pendidikan_wali');
  $penghasilan_wali = $this->input->post('penghasilan_wali');
  $path = './assets/upload/siswa/';

   // get foto
   $config['upload_path'] = './assets/upload/siswa/';
   $config['allowed_types'] = 'jpg|png|jpeg|gif';
   $config['max_size'] = '2048';  //2MB max
   $config['max_width'] = '4480'; // pixel
   $config['max_height'] = '4480'; // pixel
   $this->upload->initialize($config);
       if ($this->upload->do_upload('foto')) {
           $foto = $this->upload->data();
  

          $data = array(
              'kode_siswa' => $kode_siswa,
              'nama_lengkap' => $nama_lengkap,
              'nama_panggilan' => $nama_panggilan,
              'nisn' => $nisn,
              'no_ijazah' => $no_ijazah,
              'jenis_kelamin' => $jenis_kelamin,
              'tempat_lahir' => $tempat_lahir,
              'tanggal_lahir' => $tanggal_lahir,
              'agama' => $agama,
              'alamat' => $alamat,
              'email' => $email,
              'no_telp' => $no_telp,
              'nama_ayah' => $nama_ayah,
              'pekerjaan_ayah' => $pekerjaan_ayah,
              'pendidikan_ayah' => $pendidikan_ayah,
              'pendidikan_ayah' => $pendidikan_ayah,
              'penghasilan_ayah' => $penghasilan_ayah,
              'nama_ibu' => $nama_ibu,
              'pekerjaan_ibu' => $pekerjaan_ibu,
              'pendidikan_ibu' => $pendidikan_ibu,
              'pendidikan_ibu' => $pendidikan_ibu,
              'penghasilan_ibu' => $penghasilan_ibu,
              'nama_wali' => $nama_wali,
              'pekerjaan_wali' => $pekerjaan_wali,
              'pendidikan_wali' => $pendidikan_wali,
              'pendidikan_wali' => $pendidikan_wali,
              'penghasilan_wali' => $penghasilan_wali,
              'foto' => $foto['file_name'],
          );

          $where = array(
            'kode_siswa' => $kode_siswa );

            @unlink($path . $this->input->post('filelama'));
          $this->M_formulir->update_data($where, $data, 'tbl_siswa');
          $this->session->set_flashdata('message', '<div class="alert alert-success shadow-lg" role="alert">
          Data Berhasil di Update
    </div>');
          redirect('admin/formulir/data_formulir');
        } else {

          $data = array(
            'kode_siswa' => $kode_siswa,
            'nama_lengkap' => $nama_lengkap,
            'nama_panggilan' => $nama_panggilan,
            'nisn' => $nisn,
            'no_ijazah' => $no_ijazah,
            'jenis_kelamin' => $jenis_kelamin,
            'tempat_lahir' => $tempat_lahir,
            'tanggal_lahir' => $tanggal_lahir,
            'agama' => $agama,
            'alamat' => $alamat,
            'email' => $email,
            'no_telp' => $no_telp,
            'nama_ayah' => $nama_ayah,
            'pekerjaan_ayah' => $pekerjaan_ayah,
            'pendidikan_ayah' => $pendidikan_ayah,
            'pendidikan_ayah' => $pendidikan_ayah,
            'penghasilan_ayah' => $penghasilan_ayah,
            'nama_ibu' => $nama_ibu,
            'pekerjaan_ibu' => $pekerjaan_ibu,
            'pendidikan_ibu' => $pendidikan_ibu,
            'pendidikan_ibu' => $pendidikan_ibu,
            'penghasilan_ibu' => $penghasilan_ibu,
            'nama_wali' => $nama_wali,
            'pekerjaan_wali' => $pekerjaan_wali,
            'pendidikan_wali' => $pendidikan_wali,
            'pendidikan_wali' => $pendidikan_wali,
            'penghasilan_wali' => $penghasilan_wali,
        );
        $where = array(
          'kode_siswa' => $kode_siswa );
        $this->M_formulir->update_data($where, $data, 'tbl_siswa');
        $this->session->set_flashdata('message', '<div class="alert alert-success shadow-lg" role="alert">
        Data Berhasil di Update
        </div>');
              redirect('admin/formulir/data_formulir');
        }

      }


      public function export_excel(){
        $data['tampil'] = $this->M_formulir->tampil_data()->result();
    
        require(APPPATH. '/PHPExcel-1.8/Classes/PHPExcel.php');
        require(APPPATH. '/PHPExcel-1.8/Classes/PHPExcel/Writer/Excel2007.php');
    
        $objPHPExcel = new PHPExcel();
    
        $objPHPExcel->getProperties()->setCreator("idr corner");
        $objPHPExcel->getProperties()->setLastModifiedBy("idr corner");
        $objPHPExcel->getProperties()->setTitle("Data Siswa");
        $objPHPExcel->getProperties()->setSubject("");
        $objPHPExcel->getProperties()->setDescription("");
    
        $objPHPExcel->setActiveSheetIndex(0);
        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A1:W1');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue ( "A1", "DATA SISWA" );
        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A2:C2');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue ( "A2", "Sekolah : Nassaschool" );
        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A3:C3');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue ( "A3", "Alamat : Jln Bojong Nangka" );
    
    
    
    
        $objPHPExcel->getActiveSheet()->setCellValue('A5', 'No');
        $objPHPExcel->getActiveSheet()->setCellValue('B5', 'Kode Siswa');
        $objPHPExcel->getActiveSheet()->setCellValue('C5', 'Nama');
        $objPHPExcel->getActiveSheet()->setCellValue('D5', 'NISN');
        $objPHPExcel->getActiveSheet()->setCellValue('E5', 'No. Ijazah');
        $objPHPExcel->getActiveSheet()->setCellValue('F5', 'Tempat');
        $objPHPExcel->getActiveSheet()->setCellValue('G5', 'Tanggal Lahir');
        $objPHPExcel->getActiveSheet()->setCellValue('H5', 'Jenis Kelamin');
        $objPHPExcel->getActiveSheet()->setCellValue('I5', 'Email');
        $objPHPExcel->getActiveSheet()->setCellValue('J5', 'No. Telpon');
        $objPHPExcel->getActiveSheet()->setCellValue('K5', 'Alamat');
        $objPHPExcel->getActiveSheet()->setCellValue('L5', 'Nama Ayah');
        $objPHPExcel->getActiveSheet()->setCellValue('M5', 'Pendidikan Ayah');
        $objPHPExcel->getActiveSheet()->setCellValue('N5', 'Pekerjaan Ayah');
        $objPHPExcel->getActiveSheet()->setCellValue('O5', 'Penghasilan Ayah');
        $objPHPExcel->getActiveSheet()->setCellValue('P5', 'Nama Ibu');
        $objPHPExcel->getActiveSheet()->setCellValue('Q5', 'Pendidikan Ibu');
        $objPHPExcel->getActiveSheet()->setCellValue('R5', 'Pekerjaan Ibu');
        $objPHPExcel->getActiveSheet()->setCellValue('S5', 'Penghasilan Ibu');
        $objPHPExcel->getActiveSheet()->setCellValue('T5', 'Nama Wali');
        $objPHPExcel->getActiveSheet()->setCellValue('U5', 'Pendidikan Wali');
        $objPHPExcel->getActiveSheet()->setCellValue('V5', 'Pekerjaan Wali');
        $objPHPExcel->getActiveSheet()->setCellValue('W5', 'Penghasilan Wali');
    
        $baris=6;
        $x=1;
        
        foreach($data['tampil'] as $data){
          if($data->action === '1'):
          $objPHPExcel->getActiveSheet()->setCellValue('A'.$baris, $x );
          $objPHPExcel->getActiveSheet()->setCellValue('B'.$baris, $data->kode_siswa);
          $objPHPExcel->getActiveSheet()->setCellValue('C'.$baris, $data->nama_lengkap);
          $objPHPExcel->getActiveSheet()->setCellValue('D'.$baris, $data->nisn);
          $objPHPExcel->getActiveSheet()->setCellValue('E'.$baris, $data->no_ijazah);
          $objPHPExcel->getActiveSheet()->setCellValue('F'.$baris, $data->tempat_lahir);
          $objPHPExcel->getActiveSheet()->setCellValue('G'.$baris, $data->tanggal_lahir);
          $objPHPExcel->getActiveSheet()->setCellValue('H'.$baris, $data->jenis_kelamin);
          $objPHPExcel->getActiveSheet()->setCellValue('I'.$baris, $data->email);
          $objPHPExcel->getActiveSheet()->setCellValue('J'.$baris, $data->no_telp);
          $objPHPExcel->getActiveSheet()->setCellValue('K'.$baris, $data->alamat);
          $objPHPExcel->getActiveSheet()->setCellValue('L'.$baris, $data->nama_ayah);
          $objPHPExcel->getActiveSheet()->setCellValue('M'.$baris, $data->pendidikan_ayah);
          $objPHPExcel->getActiveSheet()->setCellValue('N'.$baris, $data->pekerjaan_ayah);
          $objPHPExcel->getActiveSheet()->setCellValue('O'.$baris, $data->penghasilan_ayah);
          $objPHPExcel->getActiveSheet()->setCellValue('P'.$baris, $data->nama_ibu);
          $objPHPExcel->getActiveSheet()->setCellValue('Q'.$baris, $data->pendidikan_ibu);
          $objPHPExcel->getActiveSheet()->setCellValue('R'.$baris, $data->pekerjaan_ibu);
          $objPHPExcel->getActiveSheet()->setCellValue('S'.$baris, $data->penghasilan_ibu);
          $objPHPExcel->getActiveSheet()->setCellValue('T'.$baris, $data->nama_wali);
          $objPHPExcel->getActiveSheet()->setCellValue('U'.$baris, $data->pendidikan_wali);
          $objPHPExcel->getActiveSheet()->setCellValue('V'.$baris, $data->pekerjaan_wali);
          $objPHPExcel->getActiveSheet()->setCellValue('W'.$baris, $data->penghasilan_wali);
         
    
          $x++;
          $baris++;
          endif;
        }
    
    
        // membuat fill color background cell
        $objPHPExcel->getSheet(0)->getStyle('A5:W5')->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
        $objPHPExcel->getSheet(0)->getStyle('A5:W5')->getFill()
        ->getStartColor()->setRGB('FDAB9F');
    
        $objPHPExcel->getActiveSheet()->getStyle("A5:W76")->applyFromArray(
          array(
              'borders' => array(
                   'allborders' => array(
                      'style' => PHPExcel_Style_Border::BORDER_THIN
                      )
                 )
          )
         );
        
    
        $objPHPExcel->getSheet(0)->getColumnDimension('A')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('B')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('C')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('D')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('E')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('F')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('G')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('H')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('I')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('J')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('K')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('L')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('M')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('N')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('O')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('P')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('Q')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('R')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('S')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('T')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('U')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('V')->setAutoSize(true);
        $objPHPExcel->getSheet(0)->getColumnDimension('W')->setAutoSize(true);
    
        $filename="Data-Siswa-".date("d-m-Y-H-i-s").'.xlsx';
    
        $objPHPExcel->getActiveSheet()->setTitle("Data Siswa");
        ob_end_clean();
    
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="'.$filename.'"');
        header('Cache-Control: max-age=0');
    
        $writer=PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $writer->save('php://output');
    
        exit;
        
      }
    
}

