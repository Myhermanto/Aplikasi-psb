<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Post extends CI_Controller
{

  function __construct(){
    parent::__construct();
      if(!isset($_SESSION['user_email'])){
      redirect('administrator');
      }
      $this->load->model('M_user');
      $this->load->model('M_post');
      $this->load->library('upload');

    
  }

  public function index()
  {
    $data['title'] = 'Post';
    $data['tampil'] = $this->M_post->tampil_data();
    $data['user'] = $this->db->get_where('tbl_admin', ['user_email' =>
    $this->session->userdata('user_email')])->row_array();
    
    $this->load->view('templates/v_header', $data);
    $this->load->view('admin/v_dashboard_topbar', $data);
    $this->load->view('admin/post_data', $data);
    $this->load->view('templates/v_footer', $data);
  }

  public function detail($id)
  {
      $tampil = $this->M_post->detail_data($id);
      $data['tampil'] = $tampil;
      $data['title'] = 'Post';
      $data['user'] = $this->db->get_where('tbl_admin', ['user_email' =>
      $this->session->userdata('user_email')])->row_array();

      $this->load->view('templates/v_header', $data);
      $this->load->view('admin/v_dashboard_topbar', $data);
      $this->load->view('admin/post_tampil', $data);
      $this->load->view('templates/v_footer', $data);
  }


  public function new_post()
  {
    $data['title'] = 'New Post';
    $data['user'] = $this->db->get_where('tbl_admin', ['user_email' =>
    $this->session->userdata('user_email')])->row_array();
    
    $this->load->view('templates/v_header', $data);
    $this->load->view('admin/v_dashboard_topbar', $data);
    $this->load->view('admin/post', $data);
    $this->load->view('templates/v_footer', $data);
  }

  public function simpan_post() {
    $id_post = $this->input->post('id_post');
    $judul = $this->input->post('judul');
    $isi = $this->input->post('isi');
    $kategori = $this->input->post('kategori');
    $status_post = $this->input->post('status_post');
    $author = "";
    $user = $this->M_user->cek_admin()->result_array();
    $tanggal_post = date('Y-m-d', strtotime($this->input->post('tanggal_post')));

    // get foto
   $config['upload_path'] = './assets/upload/public/';
   $config['allowed_types'] = 'jpg|png|jpeg|gif';
   $config['max_size'] = '2048';  //2MB max
   $config['max_width'] = '4480'; // pixel
   $config['max_height'] = '4480'; // pixel
   $this->upload->initialize($config);
   if (!empty($_FILES['foto']['name'])) {
       if ($this->upload->do_upload('foto')) {
           $foto = $this->upload->data();

           foreach ($user as $row) {
            $author = $row['user_name'];
          }

            $data = array(
                'id_post' => $id_post,
                'judul' => $judul,
                'isi' => $isi,
                'kategori' => $kategori,
                'author' => $author,
                'gambar' => $foto['file_name'],
                'status_post' => $status_post
            );

            $this->M_post->simpan_data($data, 'tbl_post');
            $this->session->set_flashdata('message', '<div class="alert alert-success shadow-lg" role="alert">
      Data Berhasil di Update
      </div>');
            redirect('admin/post');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-warning shadow-lg" role="alert">
      Data, gagal diupdate
      </div>');
            redirect('admin/post');
        }
    } else {
        foreach ($user as $row) {
            $author = $row['user_name'];
          }

        $data = array(
            'id_post' => $id_post,
            'judul' => $judul,
            'isi' => $isi,
            'kategori' => $kategori,
            'author' => $author,
            'gambar' => '',
            'status_post' => $status_post
        );

        $this->M_post->simpan_data($data, 'tbl_post');
        $this->session->set_flashdata('message', '<div class="alert alert-success shadow-lg" role="alert">
  Data Berhasil
  </div>');
              redirect('admin/post');
    }
}
  
public function edit_post($id) {

  $where = array('id_post' => $id);
  $data['post'] = $this->M_post->edit_data($where, 'tbl_post')->result();

  $data['title'] = 'Edit Post';
  $data['user'] = $this->db->get_where('tbl_admin', ['user_email' =>
    $this->session->userdata('user_email')])->row_array();

    $this->load->view('templates/v_header', $data);
    $this->load->view('admin/v_dashboard_topbar', $data);
    $this->load->view('admin/post_edit', $data);
    $this->load->view('templates/v_footer', $data);
}


public function update_post() {

  $id_post = $this->input->post('id_post');
    $judul = $this->input->post('judul');
    $isi = $this->input->post('isi');
    $kategori = $this->input->post('kategori');
    $status_post = $this->input->post('status_post');
    $author = "";
    $user = $this->M_user->cek_admin()->result_array();
    $tanggal_post = date('Y-m-d', strtotime($this->input->post('tanggal_post')));
    $path = './assets/upload/public/';
    $where = array(
      'id_post' => $id_post
    );

    // get foto
   $config['upload_path'] = './assets/upload/public/';
   $config['allowed_types'] = 'jpg|png|jpeg|gif';
   $config['max_size'] = '2048';  //2MB max
   $config['max_width'] = '4480'; // pixel
   $config['max_height'] = '4480'; // pixel
   $this->upload->initialize($config);
       if ($this->upload->do_upload('foto')) {
           $foto = $this->upload->data();

           foreach ($user as $row) {
            $author = $row['user_name'];
          }

            $data = array(
                'id_post' => $id_post,
                'judul' => $judul,
                'isi' => $isi,
                'kategori' => $kategori,
                'author' => $author,
                'gambar' => $foto['file_name'],
                'status_post' => $status_post
            );

            @unlink($path . $this->input->post('filelama'));

            $this->M_post->update_data($where, $data, 'tbl_post');
            $this->session->set_flashdata('message', '<div class="alert alert-success shadow-lg" role="alert">
      Data Berhasil di Update
      </div>');
            redirect('admin/post');
        } else {
          foreach ($user as $row) {
            $author = $row['user_name'];
          }

            $data = array(
                'id_post' => $id_post,
                'judul' => $judul,
                'isi' => $isi,
                'kategori' => $kategori,
                'author' => $author,
                'status_post' => $status_post
            );

            $this->session->set_flashdata('message', '<div class="alert alert-warning shadow-lg" role="alert">
      Data, Berhasil di Update...
      </div>');
            redirect('admin/post');
        }

}



public function delete($id){
  $_id = $this->db->get_where('tbl_post',['id_post' => $id])->row();
  $query = $this->db->delete('tbl_post',['id_post'=>$id]);
  if($query){
      unlink("assets/upload/public/".$_id->gambar);
  }
  redirect('admin/post');
}
 
}
