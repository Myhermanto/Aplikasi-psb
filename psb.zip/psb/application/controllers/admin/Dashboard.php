<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Dashboard extends CI_Controller
{

  function __construct(){
    parent::__construct();
      if(!isset($_SESSION['user_email'])){
      redirect('administrator');
      }
      $this->load->model('M_formulir');
      $this->load->model('M_transfer');
      $this->load->model('M_total');

  }

  public function index()
  {
    $data['title'] = 'Dashboard';
    $data['user'] = $this->db->get_where('tbl_admin', ['user_email' =>
    $this->session->userdata('user_email')])->row_array();
    $data['total_formulir'] = $this->M_total->hitungformulir();
    $data['lunas'] = $this->M_total->hitungPelunasan();
    $data['approve'] = $this->M_total->hitungApprove();


    $this->load->view('templates/v_header', $data);
    $this->load->view('admin/v_dashboard_topbar', $data);
    $this->load->view('admin/dashboard', $data);
    $this->load->view('templates/v_footer', $data);
  }

 
}
