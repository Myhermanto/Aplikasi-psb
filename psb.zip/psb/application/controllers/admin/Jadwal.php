<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Jadwal extends CI_Controller
{

  function __construct(){
    parent::__construct();
      if(!isset($_SESSION['user_email'])){
      redirect('administrator');
      }
      $this->load->model('M_jadwal');

  }

  public function index()
  {
    $data['tampil'] = $this->M_jadwal->tampil_data();
    $data['title'] = 'Jadwal Ujian';
    $data['user'] = $this->db->get_where('tbl_admin', ['user_email' =>
    $this->session->userdata('user_email')])->row_array();

    $this->load->view('templates/v_header', $data);
    $this->load->view('admin/v_dashboard_topbar', $data);
    $this->load->view('admin/jadwal_test', $data);
    $this->load->view('templates/v_footer', $data);
  }

  public function simpan_form()
  {
    $batch = $this->input->post('batch');
    $tanggal = date('Y-m-d 00:00:00', strtotime($this->input->post('tanggal')));
    $jam = $this->input->post('jam');
    $ruang= $this->input->post('ruang');

    $data = array(
        'batch' => $batch,
        'tanggal' => $tanggal,
        'jam' => $jam,
        'ruang' => $ruang,
    );

    $this->M_jadwal->simpan_data($data, 'tbl_jadwal');
    $this->session->set_flashdata('message', '<div class="alert alert-success shadow-lg" role="alert">
        Data Berhasil di Upload
        </div>');
            redirect('admin/jadwal');
  }
  
   // untuk edit 
   public function edit_data()
   {
    $id=$this->input->post('id_jadwal');
    $batch=$this->input->post('batch');
    $tanggal=$this->input->post('tanggal');
    $jam=$this->input->post('jam');
    $ruang=$this->input->post('ruang');

    $data = array(
        'batch' => $batch,
        'tanggal' => $tanggal,
        'jam' => $jam,
        'ruang' => $ruang,
    );

    $where = array (
      'id_jadwal' => $id
    );

    $this->M_jadwal->update_data($where,$data,'tbl_jadwal');
    redirect('admin/jadwal');
}






}