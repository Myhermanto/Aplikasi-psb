<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Transaksi extends CI_Controller
{

  function __construct(){
    parent::__construct();
      if(!isset($_SESSION['user_email'])){
      redirect('administrator');
      }
      $this->load->model('M_formulir');
      $this->load->model('M_transfer');

  }

  public function index()
  {
    $data['tampil'] = $this->M_transfer->tampil_data();
    $data['title'] = 'Pembayaran';
    $data['user'] = $this->db->get_where('tbl_admin', ['user_email' =>
    $this->session->userdata('user_email')])->row_array();

    $this->load->view('templates/v_header', $data);
    $this->load->view('admin/v_dashboard_topbar', $data);
    $this->load->view('admin/pembayaran', $data);
    $this->load->view('templates/v_footer', $data);
  }
  
  public function pembayaran($id)
	{
    $data['title'] = 'Konfirmasi Pembayaran';
    $data['user'] = $this->db->get_where('tbl_admin', ['user_email' =>
    $this->session->userdata('user_email')])->row_array();
    $tampil = $this->M_transfer->detail_data($id);
    $data['tampil'] = $tampil;

    $this->load->view('templates/v_header', $data);
    $this->load->view('admin/v_dashboard_topbar', $data);
    $this->load->view('admin/pembayaran_konfirmasi', $data);
    $this->load->view('templates/v_footer', $data);
  }


  public function cek_pembayaran()
  {
    $id                 = $this->input->post('kode_siswa');
    $status_pembayaran  = $this->input->post('status_pembayaran');

    $data = array(
      'status_pembayaran' => $status_pembayaran,
    );

    $where = array (
      'kode_siswa' => $id
    );

    $this->M_transfer->update_data($data,'tbl_pembayaran',$where);
    $this->M_transfer->update_data($data,'tbl_siswa',$where);

    redirect('admin/transaksi');
  }



 

}
