<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Jadwal extends CI_Controller
{
  
  function __construct(){
    parent::__construct();
      if(!isset($_SESSION['email'])){
      redirect('autentifikasi');
      }
    $this->load->model('M_user');
    $this->load->model('M_transfer');
    $this->load->model('M_jadwal');

  }

  public function index()
  {
    $data['title'] = 'Jadwal Tes';
    $data['user'] = $this->db->get_where('tbl_siswa', ['email' =>
    $this->session->userdata('email')])->row_array();
    $data['pmb'] = $this->db->get_where('tbl_pembayaran', ['email' =>
    $this->session->userdata('email')])->row_array();
    $data['tampil'] = $this->M_jadwal->tampil_data();


    $this->load->view('templates/v_header', $data);
    $this->load->view('user/v_topbar_dashboard');
    $this->load->view('user/v_sidebar_dashboard');
    $this->load->view('user/jadwal_test');
    $this->load->view('templates/v_footer');
  }

  public function cetak($id)
  {
    $data['title'] = 'Cetak';
    $data['user'] = $this->db->get_where('tbl_siswa', ['email' =>
    $this->session->userdata('email')])->row_array();
    $data['pmb'] = $this->db->get_where('tbl_pembayaran', ['email' =>
    $this->session->userdata('email')])->row_array();
    $data['tampil'] = $this->M_jadwal->tampil_data($id);


    $this->load->view('templates/v_header', $data);
    $this->load->view('user/jadwal_cetak');
    $this->load->view('templates/v_footer');
  }

  public function pdf(){
    $this->load->library('dompdf_gen');
    $data['user'] = $this->db->get_where('tbl_siswa', ['email' =>
    $this->session->userdata('email')])->row_array();
    $data['pmb'] = $this->db->get_where('tbl_pembayaran', ['email' =>
    $this->session->userdata('email')])->row_array();
    $data['tampil'] = $this->M_jadwal->tampil_data()->result_array();

    $this->load->view('user/laporan_pdf', $data);

    $paper_size = 'A4';
    $orientation = 'potrait';
    $html = $this->output->get_output();
    $this->dompdf->set_paper($paper_size, $orientation);

    $this->dompdf->load_html($html);
    $this->dompdf->render();
    $this->dompdf->stream("laporan_mahasiswa.pdf", array('attachment'=>0));



  }


}
