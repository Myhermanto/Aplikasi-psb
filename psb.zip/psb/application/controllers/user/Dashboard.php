<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Dashboard extends CI_Controller
{
  
  function __construct(){
    parent::__construct();
      if(!isset($_SESSION['email'])){
      redirect('autentifikasi');
      }
    $this->load->model('M_user');
    $this->load->model('M_transfer');
    $this->load->library('upload');

  }

  public function index()
  {
    $data['title'] = 'Dashboard Siswa';
    $data['user'] = $this->db->get_where('tbl_siswa', ['email' =>
    $this->session->userdata('email')])->row_array();
    $data['pmb'] = $this->db->get_where('tbl_pembayaran', ['email' =>
    $this->session->userdata('email')])->row_array();

    $this->load->view('templates/v_header', $data);
    $this->load->view('user/v_topbar_dashboard');
    $this->load->view('user/v_sidebar_dashboard');
    $this->load->view('user/dashboard');
    $this->load->view('templates/v_footer');
  }



}
