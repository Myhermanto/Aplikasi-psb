<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Pembayaran extends CI_Controller
{
  
  function __construct(){
    parent::__construct();
      if(!isset($_SESSION['email'])){
      redirect('autentifikasi');
      }
    $this->load->model('M_user');
    $this->load->model('M_transfer');
    $this->load->library('upload');

  }

  public function index()
  {
    $data['title'] = 'Pembayaran';
    $data['user'] = $this->db->get_where('tbl_siswa', ['email' =>
    $this->session->userdata('email')])->row_array();
    $data['pmb'] = $this->db->get_where('tbl_pembayaran', ['email' =>
    $this->session->userdata('email')])->row_array();
  
    $this->load->view('templates/v_header', $data);
    $this->load->view('user/v_topbar_dashboard', $data);
    $this->load->view('user/v_sidebar_dashboard', $data);
    $this->load->view('user/data_pembayaran', $data);
    $this->load->view('templates/v_footer', $data);
   
  }

  
  public function simpan_form() {

    $id_pembayaran = $this->input->post('id_pembayaran');;
    $kode_siswa = "";
    $nama_siswa ="";
    $email ="";
    $user = $this->M_user->cek_login()->result_array();
    // get foto
    $config['upload_path'] = './assets/upload/transfer/';
    $config['allowed_types'] = 'jpg|png|jpeg|gif';
    $config['max_size'] = '2048';  //2MB max
    $config['max_width'] = '4480'; // pixel
    $config['max_height'] = '4480'; // pixel
    $this->upload->initialize($config);
    if (!empty($_FILES['foto']['name'])) {
        if ($this->upload->do_upload('foto')) {
            $foto = $this->upload->data();

            foreach ($user as $row) {
              $kode_siswa = $row['kode_siswa'];
              $nama_siswa = $row['nama_lengkap'];
              $email = $row['email'];
            }

            $data = array(
                'id_pembayaran' => $id_pembayaran,
                'kode_siswa' => $kode_siswa,
                'nama_siswa' => $nama_siswa,
                'email' => $email,
                'bukti_pembayaran' => $foto['file_name']

            );

            $this->M_user->simpan_data($data, 'tbl_pembayaran');
            $this->session->set_flashdata('message', '<div class="alert alert-success shadow-lg" role="alert">
      Selamat, Upload Berhasil!
      </div>');
            redirect('user/pembayaran');
        } else {
          $this->session->set_flashdata('message', '<div class="alert alert-success shadow-lg" role="alert">
          Selamat, Upload Berhasil!
          </div>');
                redirect('user/pembayaran');
        }
    } else {
        echo " ";
    }
}

}
