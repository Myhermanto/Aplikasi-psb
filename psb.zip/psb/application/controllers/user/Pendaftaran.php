<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Pendaftaran extends CI_Controller
{

  function __construct(){
    parent::__construct();
      if(!isset($_SESSION['email'])){
      redirect('autentifikasi');
      }
      $this->load->model('M_user');
      $this->load->model('M_post');

    
  }

  public function index()
  {
    $data['title'] = 'Post';
    $data['tampil'] = $this->M_post->tampil_data();
    $data['user'] = $this->db->get_where('tbl_siswa', ['email' =>
      $this->session->userdata('email')])->row_array();

      $this->load->view('templates/v_header', $data);
      $this->load->view('user/v_topbar_dashboard', $data);
      $this->load->view('user/v_sidebar_dashboard', $data);
      $this->load->view('admin/post_pendaftaran', $data);
      $this->load->view('templates/v_footer', $data);
  }

  public function detail($id)
  {
      $tampil = $this->M_post->detail_data($id);
      $data['tampil'] = $tampil;
      $data['title'] = 'Post';
      $data['user'] = $this->db->get_where('tbl_siswa', ['email' =>
      $this->session->userdata('email')])->row_array();

      $this->load->view('templates/v_header', $data);
      $this->load->view('user/v_topbar_dashboard', $data);
      $this->load->view('user/v_sidebar_dashboard', $data);
      $this->load->view('admin/post_tampil', $data);
      $this->load->view('templates/v_footer', $data);
  }



}