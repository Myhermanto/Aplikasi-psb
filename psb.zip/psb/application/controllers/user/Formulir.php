<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Formulir extends CI_Controller
{

  function __construct(){
    parent::__construct();
      if(!isset($_SESSION['email'])){
      redirect('autentifikasi');
      }
      $this->load->model('M_formulir');
      $this->load->library('upload');


  }

  public function index()
  {
    $data['title'] = 'Formulir';
    $data['user'] = $this->db->get_where('tbl_siswa', ['email' =>
    $this->session->userdata('email')])->row_array();

    $this->load->view('templates/v_header', $data);
    $this->load->view('user/v_topbar_dashboard', $data);
    $this->load->view('user/v_sidebar_dashboard', $data);
    $this->load->view('user/tampil_formulir', $data);
    $this->load->view('templates/v_footer', $data);
  }


  public function edit_form($id) {
    $data['title'] = 'Formulir';
    $data['user'] = $this->db->get_where('tbl_siswa', ['email' =>
    $this->session->userdata('email')])->row_array();
    $where = array('kode_siswa' => $id);
    $data['siswa'] = $this->M_formulir->edit_data($where, 'tbl_siswa')->result();


  $this->load->view('templates/v_header', $data);
  $this->load->view('user/v_topbar_dashboard', $data);
  $this->load->view('user/v_sidebar_dashboard', $data);
  $this->load->view('user/edit_formulir', $data);
  $this->load->view('templates/v_footer', $data);
}


public function update_form() {
  $kode_siswa = $this->input->post('kode_siswa');
  $nama_lengkap = $this->input->post('nama_lengkap');
  $nama_panggilan = $this->input->post('nama_panggilan');
  $nisn = $this->input->post('nisn');
  $no_ijazah = $this->input->post('no_ijazah');
  $jenis_kelamin = $this->input->post('jenis_kelamin');
  $tempat_lahir = $this->input->post('tempat_lahir');
  $tanggal_lahir = $this->input->post('tanggal_lahir');
  $agama = $this->input->post('agama');
  $alamat= $this->input->post('alamat');
  $email = $this->input->post('email');
  $no_telp = $this->input->post('no_telp');
  $nama_ayah = $this->input->post('nama_ayah');
  $pekerjaan_ayah = $this->input->post('pekerjaan_ayah');
  $pendidikan_ayah = $this->input->post('pendidikan_ayah');
  $penghasilan_ayah = $this->input->post('penghasilan_ayah');
  $nama_ibu = $this->input->post('nama_ibu');
  $pekerjaan_ibu = $this->input->post('pekerjaan_ibu');
  $pendidikan_ibu = $this->input->post('pendidikan_ibu');
  $penghasilan_ibu = $this->input->post('penghasilan_ibu');
  $nama_wali = $this->input->post('nama_wali');
  $pekerjaan_wali = $this->input->post('pekerjaan_wali');
  $pendidikan_wali = $this->input->post('pendidikan_wali');
  $penghasilan_wali = $this->input->post('penghasilan_wali');
  $path = './assets/upload/siswa/';

   // get foto
   $config['upload_path'] = './assets/upload/siswa/';
   $config['allowed_types'] = 'jpg|png|jpeg|gif';
   $config['max_size'] = '2048';  //2MB max
   $config['max_width'] = '4480'; // pixel
   $config['max_height'] = '4480'; // pixel
   $this->upload->initialize($config);
       if ($this->upload->do_upload('foto')) {
           $foto = $this->upload->data();
  

          $data = array(
              'kode_siswa' => $kode_siswa,
              'nama_lengkap' => $nama_lengkap,
              'nama_panggilan' => $nama_panggilan,
              'nisn' => $nisn,
              'no_ijazah' => $no_ijazah,
              'jenis_kelamin' => $jenis_kelamin,
              'tempat_lahir' => $tempat_lahir,
              'tanggal_lahir' => $tanggal_lahir,
              'agama' => $agama,
              'alamat' => $alamat,
              'email' => $email,
              'no_telp' => $no_telp,
              'nama_ayah' => $nama_ayah,
              'pekerjaan_ayah' => $pekerjaan_ayah,
              'pendidikan_ayah' => $pendidikan_ayah,
              'pendidikan_ayah' => $pendidikan_ayah,
              'penghasilan_ayah' => $penghasilan_ayah,
              'nama_ibu' => $nama_ibu,
              'pekerjaan_ibu' => $pekerjaan_ibu,
              'pendidikan_ibu' => $pendidikan_ibu,
              'pendidikan_ibu' => $pendidikan_ibu,
              'penghasilan_ibu' => $penghasilan_ibu,
              'nama_wali' => $nama_wali,
              'pekerjaan_wali' => $pekerjaan_wali,
              'pendidikan_wali' => $pendidikan_wali,
              'pendidikan_wali' => $pendidikan_wali,
              'penghasilan_wali' => $penghasilan_wali,
              'foto' => $foto['file_name'],
          );

          $where = array(
            'kode_siswa' => $kode_siswa );

            @unlink($path . $this->input->post('filelama'));
          $this->M_formulir->update_data($where, $data, 'tbl_siswa');
          $this->session->set_flashdata('message', '<div class="alert alert-success shadow-lg" role="alert">
          Data Berhasil di Update
    </div>');
          redirect('user/formulir');
        } else {

          $data = array(
            'kode_siswa' => $kode_siswa,
            'nama_lengkap' => $nama_lengkap,
            'nama_panggilan' => $nama_panggilan,
            'nisn' => $nisn,
            'no_ijazah' => $no_ijazah,
            'jenis_kelamin' => $jenis_kelamin,
            'tempat_lahir' => $tempat_lahir,
            'tanggal_lahir' => $tanggal_lahir,
            'agama' => $agama,
            'alamat' => $alamat,
            'email' => $email,
            'no_telp' => $no_telp,
            'nama_ayah' => $nama_ayah,
            'pekerjaan_ayah' => $pekerjaan_ayah,
            'pendidikan_ayah' => $pendidikan_ayah,
            'pendidikan_ayah' => $pendidikan_ayah,
            'penghasilan_ayah' => $penghasilan_ayah,
            'nama_ibu' => $nama_ibu,
            'pekerjaan_ibu' => $pekerjaan_ibu,
            'pendidikan_ibu' => $pendidikan_ibu,
            'pendidikan_ibu' => $pendidikan_ibu,
            'penghasilan_ibu' => $penghasilan_ibu,
            'nama_wali' => $nama_wali,
            'pekerjaan_wali' => $pekerjaan_wali,
            'pendidikan_wali' => $pendidikan_wali,
            'pendidikan_wali' => $pendidikan_wali,
            'penghasilan_wali' => $penghasilan_wali,
        );

        $where = array(
          'kode_siswa' => $kode_siswa );

        $this->M_formulir->update_data($where, $data, 'tbl_siswa');
        $this->session->set_flashdata('message', '<div class="alert alert-success shadow-lg" role="alert">
        Data Berhasil di Update
        </div>');
              redirect('user/formulir');
        }

      
}



}
