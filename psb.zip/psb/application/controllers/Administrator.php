<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Administrator extends CI_Controller
{


  public function index()
  {
    $data['title'] = 'Login Admin';
    $this->form_validation->set_rules('user_email', 'Email', 'required|trim|valid_email');
    $this->form_validation->set_rules('password', 'Password', 'required|trim');

    if ($this->form_validation->run() == false) {
      $this->load->view('templates/v_headerlg', $data);
      $this->load->view('admin/login');
      $this->load->view('templates/v_footerlg');
    } else {
      $this->_login();
    }
  }

  private function _login()
  {
    $email = $this->input->post('user_email');
    $password = $this->input->post('password');

    $user = $this->db->get_where('tbl_admin', ['user_email' => $email])->row_array();

    //jika usernya ada 
    if ($user) {
      //user aktif
      if ($user['user_status'] == 1) {
        //cek password
        if (password_verify($password, $user['user_password'])) {
          $data = [
            'user_email' => $user['user_email'],
            'user_level' => $user['user_level']
          ];
          $this->session->set_userdata($data);
          if ($user['user_level'] == 1) {
            redirect('admin/dashboard');
          } else {
            redirect('#');
          }
        } else {
          $this->session->set_flashdata('message', '<div class="alert alert-danger shadow-lg" 
                    role ="alert"> Wrong Password!</div>');
          redirect('administrator');
        }
      } else {
        $this->session->set_flashdata('message', '<div class="alert alert-danger shadow-lg" 
                role ="alert">This email has not been activated!</div>');
        redirect('administrator');
      }
    } else {
      $this->session->set_flashdata('message', '<div class="alert alert-danger shadow-lg" 
            role ="alert"> Email is not resgitered</div>');
      redirect('administrator');
    }
  }



  public function registration()
  {
    $data['title'] = 'Registrasi Admin';
    $data['user'] = $this->db->get_where('tbl_admin', ['user_email' =>
    $this->session->userdata('user_email')])->row_array();

    

    $this->form_validation->set_rules('user_name', 'username', 'required');
    $this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[3]|matches[password1]', [
      'matches' => 'Password dont match!',
      'min_length' => 'Password too short!'
    ]);
    $this->form_validation->set_rules('password1', 'Password', 'required|trim|matches[password1]');
    $this->form_validation->set_rules('user_email', 'Email', 'required|trim|is_unique[tbl_admin.user_email]', [
      'is_unique' => 'This email has already registered!'
    ]);

    if ($this->form_validation->run() == false) {
      $this->load->view('templates/v_header', $data);
      $this->load->view('admin/v_dashboard_topbar', $data);
      $this->load->view('admin/registration', $data);
      $this->load->view('templates/v_footer');
      ;
    } else { 
      $data = [
        'user_name' => htmlspecialchars($this->input->post('user_name', true)),
        'user_email' => htmlspecialchars($this->input->post('user_email', true)),
        'user_image' => 'default.jpg',
        'user_password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
        'user_status' => 0,
        'user_level' => 1,
      ];

      //token
      $token = base64_encode(random_bytes(32));
      $user_token = [
        'user_email' => $this->input->post('user_email', true),
        'token' => $token,
        'date_created' => time(),
      ];



      $this->db->insert('tbl_admin', $data);
      $this->db->insert('user_token', $user_token);
      $this->_sendEmail($token, 'verify');

      $this->session->set_flashdata('message', '<div class="alert alert-success shadow-lg" role="alert">
      Selamat, Pendaftaran Berhasil! Silahkan Aktivasi Akun!
      </div>');
      redirect('Administrator');
    }
  }

  private function _sendEmail($token, $type)
  {
      $config = [
          'protocol'  => 'smtp',
          'smtp_host' => 'ssl://smtp.googlemail.com',
          'smtp_user' => 'xx@gmail.com', //email gmail
          'smtp_pass' => 'xxx', //password gmail
          'smtp_port' => 465,
          'mailtype'  => 'html',
          'charset'   => 'utf-8',
          'newline'   => "\r\n",

      ];

      $this->load->library('email', $config);

      $this->email->from('xx@gmail.com', 'Nassa PSB');
      $this->email->to($this->input->post('user_email'));

      if ($type == 'verify') {
        $this->email->subject('Account Verification');
        $this->email->message('Click this link to verify you account :
          <a href="'.base_url() . 'administrator/verify?email='.$this->input->post('user_email').'&token='.urlencode($token).'">Activate</a>');
      }

      if($this->email->send()) {
        return true;
    } else {
        echo $this->email->print_debugger();
        die;
    }

  }

  public function verify()
  {
    $email = $this->input->get('email');
    $token = $this->input->get('token');

    $user = $this->db->get_where('tbl_admin', ['user_email' => $email])->row_array();

    if($user) {
      $user_token = $this->db->get_where('user_token', ['token' => $token])->row_array();

      if ($user_token) {
        if(time() - $user_token['date_created'] < (60*60*12)) {
          $this->db->set('user_status', 1);
          $this->db->where('user_email', $email);
          $this->db->update('tbl_admin');
          $this->db->where('user_email',$email);
          $this->db->delete('user_token');      
          $this->session->set_flashdata('message', '<div class="alert alert-success shadow-lg" role="alert">
          '.$email.' has been activated! please login!
          </div>');
        redirect('Administrator');

        }
        else {

          $this->db->where('user_email',$email);
          $this->db->delete('tbl_admin');          
          $this->db->where('user_email',$email);
          $this->db->delete('user_token');          

          $this->session->set_flashdata('message', '<div class="alert alert-danger shadow-lg" role="alert">
          Account activation failed! Token Expired</div>');
        redirect('Administrator');
        }

        
      } else {
        $this->session->set_flashdata('message', '<div class="alert alert-danger shadow-lg" role="alert">
      Account activation failed! Token Invalid</div>');
    redirect('Administrator');
      }
        

    } else {
      $this->session->set_flashdata('message', '<div class="alert alert-danger shadow-lg" role="alert">
      Account activation failed! Wrong email</div>');
    redirect('Administrator');

    }
  
  }
  



  public function logout()
  {
    $this->session->unset_userdata('user_email');
    $this->session->set_flashdata('message', '<div class="alert alert-success shadow-lg" role="alert">
      Anda berhasil keluar!
      </div>');
    redirect('Administrator');
  }
}
