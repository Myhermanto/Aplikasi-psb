<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Autentifikasi extends CI_Controller
{
  

  function __construct(){
    parent::__construct();
    
    $this->load->model('M_user');
    $this->load->library('upload');



  }

  public function index()
  {
    $data['title'] = 'Login User';
    $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
    $this->form_validation->set_rules('password', 'Password', 'required|trim');

    if ($this->form_validation->run() == false) {
      $this->load->view('templates/v_headerlg', $data);
      $this->load->view('user/login');
      $this->load->view('templates/v_footerlg');
    } else {
      $this->_login();
    }
  }

  private function _login()
  {
    $email = $this->input->post('email');
    $password = $this->input->post('password');

    $user = $this->db->get_where('tbl_siswa', ['email' => $email])->row_array();
    $password = $this->db->get_where('tbl_siswa', ['tanggal_lahir' => $password])->row_array();

    //jika usernya ada 
    if ($user) {
        //cek password
        if ($password) {
          $data = [
            'email' => $user['email'],
            'kode_siswa' => $user['kode_siswa'],
          ];
          $this->session->set_userdata($data);
          {
            redirect('user/dashboard');
          
          }
        } else {
          $this->session->set_flashdata('message', '<div class="alert alert-danger shadow-lg" 
                    role ="alert"> Wrong Password!</div>');
          redirect('autentifikasi');
     
      }
    } else {
      $this->session->set_flashdata('message', '<div class="alert alert-danger shadow-lg" 
            role ="alert"> Email is not resgitered</div>');
      redirect('autentifikasi');
    }
  }



  public function registration()
  {
    $data['title'] = 'Registrasi User';
     $data['kode'] = $this->M_user->buat_kode();

     $this->form_validation->set_rules('email', 'Email', 'required|trim|is_unique[tbl_siswa.email]', [
      'is_unique' => 'This email has already registered!'
    ]);

    $kode_siswa = $this->M_user->buat_kode();
    $nama_lengkap = $this->input->post('nama_lengkap');
    $nama_panggilan = $this->input->post('nama_panggilan');
    $nisn = $this->input->post('nisn');
    $no_ijazah = $this->input->post('no_ijazah');
    $jenis_kelamin = $this->input->post('jenis_kelamin');
    $tempat_lahir = $this->input->post('tempat_lahir');
    $tanggal_lahir = date('Y-m-d 00:00:00', strtotime($this->input->post('tanggal_lahir')));
    $agama = $this->input->post('agama');
    $alamat= $this->input->post('alamat');
    $email = $this->input->post('email');
    $no_telp = $this->input->post('no_telp');
    $nama_ayah = $this->input->post('nama_ayah');
    $pekerjaan_ayah = $this->input->post('pekerjaan_ayah');
    $pendidikan_ayah = $this->input->post('pendidikan_ayah');
    $penghasilan_ayah = $this->input->post('penghasilan_ayah');
    $nama_ibu = $this->input->post('nama_ibu');
    $pekerjaan_ibu = $this->input->post('pekerjaan_ibu');
    $pendidikan_ibu = $this->input->post('pendidikan_ibu');
    $penghasilan_ibu = $this->input->post('penghasilan_ibu');
    $nama_wali = $this->input->post('nama_wali');
    $pekerjaan_wali = $this->input->post('pekerjaan_wali');
    $pendidikan_wali = $this->input->post('pendidikan_wali');
    $penghasilan_wali = $this->input->post('penghasilan_wali');
    
    if ($this->form_validation->run() == false) {
     $this->load->view('user/regis.php');
    } else { 

      $config['upload_path'] = './assets/upload/siswa/';
    $config['allowed_types'] = 'jpg|png|jpeg|gif';
    $config['max_size'] = '2048';  //2MB max
    $config['max_width'] = '4480'; // pixel
    $config['max_height'] = '4480'; // pixel
    $this->upload->initialize($config);
    if (!empty($_FILES['foto']['name'])) {
        if ($this->upload->do_upload('foto')) {
            $foto = $this->upload->data();

            $data = array(
                'kode_siswa' => $kode_siswa,
                'nama_lengkap' => $nama_lengkap,
                'nama_panggilan' => $nama_panggilan,
                'nisn' => $nisn,
                'no_ijazah' => $no_ijazah,
                'jenis_kelamin' => $jenis_kelamin,
                'tempat_lahir' => $tempat_lahir,
                'tanggal_lahir' => $tanggal_lahir,
                'agama' => $agama,
                'alamat' => $alamat,
                'email' => $email,
                'no_telp' => $no_telp,
                'nama_ayah' => $nama_ayah,
                'pekerjaan_ayah' => $pekerjaan_ayah,
                'pendidikan_ayah' => $pendidikan_ayah,
                'pendidikan_ayah' => $pendidikan_ayah,
                'penghasilan_ayah' => $penghasilan_ayah,
                'nama_ibu' => $nama_ibu,
                'pekerjaan_ibu' => $pekerjaan_ibu,
                'pendidikan_ibu' => $pendidikan_ibu,
                'pendidikan_ibu' => $pendidikan_ibu,
                'penghasilan_ibu' => $penghasilan_ibu,
                'nama_wali' => $nama_wali,
                'pekerjaan_wali' => $pekerjaan_wali,
                'pendidikan_wali' => $pendidikan_wali,
                'pendidikan_wali' => $pendidikan_wali,
                'penghasilan_wali' => $penghasilan_wali,
                'foto' => $foto['file_name'],
                'status_pembayaran' => 0,
                'action' => 0
            );

            //token
      $token = base64_encode(random_bytes(32));
      $user_token = [
        'user_email' => $email,
        'token' => $token,
        'date_created' => time(),
      ];



      $this->db->insert('tbl_siswa', $data);
      $this->db->insert('user_token', $user_token);
      $this->_sendEmail($token, 'verify');


            $this->session->set_flashdata('message', '<div class="alert alert-info shadow-lg" role="alert">
      Selamat, Pendaftaran Berhasil! Silahkan Aktivasi
      </div>');
            redirect('autentifikasi');
        } else {
            die("gagal upload");
        }
  }
}
  }

  private function _sendEmail($token, $type)
  {
      $config = [
          'protocol'  => 'smtp',
          'smtp_host' => 'ssl://smtp.googlemail.com',
          'smtp_user' => 'xxx@gmail.com', //email gmail
          'smtp_pass' => 'xxx', //password gmail
          'smtp_port' => 465,
          'mailtype'  => 'html',
          'charset'   => 'utf-8',
          'newline'   => "\r\n",

      ];

      $this->load->library('email', $config);

      $this->email->from('xxx@gmail.com', 'Nassa PSB');
      $this->email->to($this->input->post('email'));

      if ($type == 'verify') {
        $this->email->subject('Account Verification');
        $this->email->message('Click this link to verify you account :
          <a href="'.base_url() . 'autentifikasi/verify?email='.$this->input->post('email').'&token='.urlencode($token).'">Activate</a>');
      }

      if($this->email->send()) {
        return true;
    } else {
        echo $this->email->print_debugger();
        die;
    }

  }

  public function verify()
  {
    $email = $this->input->get('email');
    $token = $this->input->get('token');

    $user = $this->db->get_where('tbl_siswa', ['email' => $email])->row_array();

    if($user) {
      $user_token = $this->db->get_where('user_token', ['token' => $token])->row_array();

      if ($user_token) {
        if(time() - $user_token['date_created'] < (60*60*12)) {
          $this->db->set('user_status', 1);
          $this->db->where('email', $email);
          $this->db->update('tbl_siswa');
          $this->db->where('user_email',$email);
          $this->db->delete('user_token');      
          $this->session->set_flashdata('message', '<div class="alert alert-success shadow-lg" role="alert">
          '.$email.' Aktivasi Berhasil! Masukan email dan tanggal lahir untuk password (ex: 1998-06-15)
          </div>');
        redirect('autentifikasi');

        }
        else {

          $this->db->where('email',$email);
          $this->db->delete('tbl_siswa');          
          $this->db->where('user_email',$email);
          $this->db->delete('user_token');          

          $this->session->set_flashdata('message', '<div class="alert alert-danger shadow-lg" role="alert">
          Account activation failed! Token Expired</div>');
        redirect('autentifikasi');
        }

        
      } else {
        $this->session->set_flashdata('message', '<div class="alert alert-danger shadow-lg" role="alert">
      Account activation failed! Token Invalid</div>');
    redirect('autentifikasi');
      }
        

    } else {
      $this->session->set_flashdata('message', '<div class="alert alert-danger shadow-lg" role="alert">
      Account activation failed! Wrong email</div>');
    redirect('autentifikasi');

    }
  
  }


  
  
  
  public function logout()
  {
    $this->session->unset_userdata('email');
    $this->session->set_flashdata('message', '<div class="alert alert-success shadow-lg" role="alert">
      Anda berhasil keluar!
      </div>');
    redirect('Autentifikasi');
  }
}
