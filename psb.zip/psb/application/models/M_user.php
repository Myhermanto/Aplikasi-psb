<?php

class M_user extends CI_Model {
    
		function cek_login (){
			$email = $this->session->email;
			$this->db->where('email', $email);
			$result = $this->db->get('tbl_siswa');
			return $result;
	}

	function cek_admin (){
		$email = $this->session->user_email;
		$this->db->where('user_email', $email);
		$result = $this->db->get('tbl_admin');
		return $result;
}


public function buat_kode()   {

		  $this->db->select('RIGHT(tbl_siswa.kode_siswa,4) as kode', FALSE);
		  $this->db->order_by('kode_siswa','DESC');    
		  $this->db->limit(1);    
		  $query = $this->db->get('tbl_siswa');      //cek apakah sudah ada kode di tabel.    
		  if($query->num_rows() <> 0){      
		   //jika kode sudah ada.      
		   $data = $query->row();      
		   $kode = intval($data->kode) + 1;    
		  }
		  else {      
		   //jika kode belum ada      
		   $kode = 1;    
		  }
		  $year = date("Y");
		  $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT); // angka 4 menunjukkan jumlah digit angka 0
		  $kodejadi = "SMA-".$year."-".$kodemax; 
		  return $kodejadi;  
	}


    public function simpan_data($data, $table) {
        $this->db->insert($table, $data);
    }

    public function edit_data($where, $table) {
        return $this->db->get_where($where, $table);
    }

    public function update_data($where, $data, $table) {
        $this->db->where($where);
        $this->db->update($table, $data);
    }

    public function hapus_data($where, $table) {
        $this->db->where($where);
        $this->db->delete($table);
	}
	
	public function get_pengguna_login($kode){
		$hsl=$this->db->query("SELECT * FROM tbl_admin where id_user='$kode'");
		return $hsl;
	}
  
}

?>