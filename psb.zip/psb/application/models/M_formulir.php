<?php

class M_formulir extends CI_Model {

    public function tampil_data() {
        return $this->db->get('tbl_siswa');
    }

    public function getpadding($limit, $offset)
{
     $this->db->select('*');
     $this->db->from('tbl_siswa');
     $this->db->order_by('kode_siswa', 'ASC');
     $this->db->limit($limit, $offset);

     return $this->db->get();
}

    public function detail_data($id = NULL) {
        $query = $this->db->get_where('tbl_siswa', array('kode_siswa' => $id));
        return $query->result_array();
    }

    public function simpan_data($data, $table) {
        $this->db->insert($table, $data);
    }

    public function edit_data($where, $table) {
        return $this->db->get_where($table, $where);
    }

    public function update_data($where, $data, $table) {
        $this->db->where($where);
        $this->db->update($table, $data);
    }

    public function hapus_data($where, $table) {
        $this->db->where($where);
        $this->db->delete($table);
    }

}
