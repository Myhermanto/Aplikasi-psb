<?php

class M_transfer extends CI_Model {


    public function tampil_data() {
        return $this->db->get('tbl_pembayaran');
    }

    public function simpan_data($where, $table) {
        return $this->db->get_where($table, $where);
    }

    public function edit_data($where, $table) {
        return $this->db->get_where($table, $where);
    }

    public function update_data($data, $table, $where) {
        $this->db->where($where);
        $this->db->update($table, $data);
    }

    public function hapus_data($where, $table) {
        $this->db->where($where);
        $this->db->delete($table);
    }

    public function update_status($id,$status){
        $data['action'] = $status;
        $this->db->where('kode_siswa', $id);
        $this->db->update('tbl_siswa',$data);
  
}

public function detail_data($id = NULL) {
    $query = $this->db->get_where('tbl_pembayaran', array('kode_siswa' => $id));
    return $query->result_array();
}

}