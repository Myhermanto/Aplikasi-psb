<?php

class M_total extends CI_Model {

    public function hitungformulir()
{   
    $query = $this->db->get('tbl_siswa');
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitungPelunasan()
{
 $query = $this->db->query('SELECT * FROM tbl_pembayaran WHERE status_pembayaran= "1"');
 $lunas=$query->num_rows();
 return $lunas;
 }

public function hitungApprove()
{
 $query = $this->db->query('SELECT * FROM tbl_siswa WHERE action= "1"');
 $lunas=$query->num_rows();
 return $lunas;
 }


}
